const textInput = document.getElementById('textInput');
const wordCount = document.getElementById('wordCount');
const charCountWithSpaces = document.getElementById('charCountWithSpaces');
const charCountWithoutSpaces = document.getElementById('charCountWithoutSpaces');
const lineCount = document.getElementById('lineCount');
const paragraphCount = document.getElementById('paragraphCount');
const sentenceCount = document.getElementById('sentenceCount');
const avgWordLength = document.getElementById('avgWordLength');
const readingTime = document.getElementById('readingTime');
const keywordInput = document.getElementById('keywordInput');
const keywordDensity = document.getElementById('keywordDensity');

textInput.addEventListener('input', updateCounts);

function updateCounts() {
  const text = textInput.value;

  const words = text.trim().split(/\s+/).filter(word => word.length > 0);
  wordCount.textContent = words.length;

  charCountWithSpaces.textContent = text.length;
  charCountWithoutSpaces.textContent = text.replace(/\s+/g, '').length;

  const lines = text.split(/\n/).filter(line => line.trim() !== '');
  lineCount.textContent = lines.length;

  const paragraphs = text.split(/\n{2,}/).filter(p => p.trim() !== '');
  paragraphCount.textContent = paragraphs.length;

  const sentences = text.split(/[.!?]+/).filter(s => s.trim() !== '');
  sentenceCount.textContent = sentences.length;

  const totalWordLength = words.reduce((sum, w) => sum + w.length, 0);
  avgWordLength.textContent = words.length ? (totalWordLength / words.length).toFixed(2) : 0;

  const time = Math.ceil(words.length / 200);
  readingTime.textContent = time + ' min';

  const keyword = keywordInput.value.trim().toLowerCase();
  if(keyword && words.length) {
    const keywordCount = words.filter(w => w.toLowerCase() === keyword).length;
    const density = ((keywordCount / words.length) * 100).toFixed(2);
    keywordDensity.textContent = `${density}% (${keywordCount} times)`;
  } else {
    keywordDensity.textContent = '-';
  }
}

function copyText() {
  textInput.select();
  textInput.setSelectionRange(0, 99999);
  navigator.clipboard.writeText(textInput.value);
  alert('Text copied to clipboard!');
}

function clearText() {
  textInput.value = '';
  keywordInput.value = '';
  updateCounts();
}

function toggleDarkMode() {
  document.body.classList.toggle('dark');
}

function exportTXT() {
  const blob = new Blob([textInput.value], { type: 'text/plain' });
  const link = document.createElement('a');
  link.download = 'text.txt';
  link.href = URL.createObjectURL(blob);
  link.click();
}

async function exportPDF() {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  const text = textInput.value;
  const lines = doc.splitTextToSize(text, 180);
  doc.text(lines, 10, 10);
  doc.save('text.pdf');
}
